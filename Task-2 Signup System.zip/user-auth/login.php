<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username_email = trim($_POST["username_email"]);
    $password = $_POST["password"];

    if (empty($username_email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username_email, $username_email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($id, $username, $hashed);
            $stmt->fetch();
            if (password_verify($password, $hashed)) {
                $_SESSION["user"] = $username;
                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Incorrect username/email or password.";
            }
        } else {
            $error = "User does not exist.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="style.css"><title>Login</title></head>
<body>
<h2>Login</h2>
<?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
<form method="POST">
    <input type="text" name="username_email" placeholder="Username or Email"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <button type="submit">Login</button>
</form>
<a href="signup.php">Don't have an account? Signup</a>
</body>
</html>
