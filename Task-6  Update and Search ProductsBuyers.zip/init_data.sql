CREATE TABLE IF NOT EXISTS buyers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    fullname VARCHAR(100),
    city VARCHAR(100),
    email VARCHAR(100)
);
INSERT INTO buyers (fullname, city, email) VALUES ('Ananya Rao', 'Hyderabad', 'ananya@example.com');