<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'mod_task6';
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die('DB Connection Error: ' . $conn->connect_error);
}
?>