package task4;

import javax.swing.*;

public class LoginForm extends JFrame {

    public LoginForm() {
        setTitle("Login Screen");
        setSize(300, 160);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new JLabel("This is a dummy login screen.", SwingConstants.CENTER));
    }
}
