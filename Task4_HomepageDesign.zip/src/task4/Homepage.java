package task4;

import javax.swing.*;
import java.awt.*;

public class Homepage extends JFrame {

    public Homepage() {
        setTitle("Task 4 Homepage");
        setSize(420, 320);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel header = new JLabel("Welcome to Task 4", SwingConstants.CENTER);
        header.setFont(new Font("Serif", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel greet = new JLabel("Hello, Java User!", SwingConstants.CENTER);
        JButton profileBtn = new JButton("Open Profile");
        JButton settingBtn = new JButton("Go to Settings");
        JButton logoutBtn = new JButton("Log Out");

        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });

        centerPanel.add(greet);
        centerPanel.add(profileBtn);
        centerPanel.add(settingBtn);
        centerPanel.add(logoutBtn);

        add(centerPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Homepage().setVisible(true));
    }
}
