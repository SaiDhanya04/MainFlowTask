import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        String[] options = {
            "Add Product", "Add Buyer",
            "Delete Product", "Delete Buyer"
        };

        String choice = (String) JOptionPane.showInputDialog(null,
            "Choose an action:", "Main Menu",
            JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (choice == null) return;

        switch (choice) {
            case "Add Product": new ProductForm(); break;
            case "Add Buyer": new BuyerForm(); break;
            case "Delete Product": new DeleteProduct(); break;
            case "Delete Buyer": new DeleteBuyer(); break;
        }
    }
}