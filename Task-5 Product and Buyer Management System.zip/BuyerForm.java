import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BuyerForm extends JFrame {
    JTextField nameField, emailField, phoneField;
    JTextArea addressArea;
    JButton submitButton;

    public BuyerForm() {
        setTitle("Add Buyer");
        setLayout(new GridLayout(5, 2, 5, 5));

        nameField = new JTextField(); emailField = new JTextField();
        phoneField = new JTextField(); addressArea = new JTextArea();
        submitButton = new JButton("Add Buyer");

        add(new JLabel("Name:")); add(nameField);
        add(new JLabel("Email:")); add(emailField);
        add(new JLabel("Phone:")); add(phoneField);
        add(new JLabel("Address:")); add(new JScrollPane(addressArea));
        add(new JLabel("")); add(submitButton);

        submitButton.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();
                String sql = "INSERT INTO buyers(name, email, phone, address) VALUES (?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, nameField.getText());
                pst.setString(2, emailField.getText());
                pst.setString(3, phoneField.getText());
                pst.setString(4, addressArea.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Buyer added successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        setSize(400, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}