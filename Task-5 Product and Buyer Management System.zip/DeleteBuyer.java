import javax.swing.*;
import java.sql.*;

public class DeleteBuyer extends JFrame {
    public DeleteBuyer() {
        setTitle("Delete Buyer");
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        try {
            Connection con = DBConnection.getConnection();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM buyers");

            while (rs.next()) {
                int id = rs.getInt("id");
                String info = id + ": " + rs.getString("name") + " - " + rs.getString("email");
                JButton deleteBtn = new JButton("Delete " + info);
                add(deleteBtn);

                deleteBtn.addActionListener(e -> {
                    try {
                        PreparedStatement ps = con.prepareStatement("DELETE FROM buyers WHERE id=?");
                        ps.setInt(1, id);
                        ps.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Deleted!");
                        dispose();
                        new DeleteBuyer();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, ex.getMessage());
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        setSize(400, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}