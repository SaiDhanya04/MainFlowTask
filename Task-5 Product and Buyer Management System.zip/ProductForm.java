import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ProductForm extends JFrame {
    JTextField nameField, categoryField, priceField, quantityField;
    JTextArea descriptionArea;
    JButton submitButton;

    public ProductForm() {
        setTitle("Add Product");
        setLayout(new GridLayout(6, 2, 5, 5));
        
        nameField = new JTextField(); categoryField = new JTextField();
        priceField = new JTextField(); quantityField = new JTextField();
        descriptionArea = new JTextArea();

        submitButton = new JButton("Add Product");

        add(new JLabel("Name:")); add(nameField);
        add(new JLabel("Category:")); add(categoryField);
        add(new JLabel("Price:")); add(priceField);
        add(new JLabel("Quantity:")); add(quantityField);
        add(new JLabel("Description:")); add(new JScrollPane(descriptionArea));
        add(new JLabel("")); add(submitButton);

        submitButton.addActionListener(e -> {
            try {
                Connection con = DBConnection.getConnection();
                String sql = "INSERT INTO products(name, category, price, quantity, description) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, nameField.getText());
                pst.setString(2, categoryField.getText());
                pst.setDouble(3, Double.parseDouble(priceField.getText()));
                pst.setInt(4, Integer.parseInt(quantityField.getText()));
                pst.setString(5, descriptionArea.getText());
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Product added successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}